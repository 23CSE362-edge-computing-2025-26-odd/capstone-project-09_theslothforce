package org.example.jsprr;

import java.util.*;

public class MainJSPRRSimulation {

    public static void main(String[] args) throws Exception {
        // ========================
        // 1. Define base stations and Cloud
        // ========================
        BaseStationDevice bs1 = new BaseStationDevice("BS1", 50, 60, 50, 50);
        BaseStationDevice bs2 = new BaseStationDevice("BS2", 50, 60, 50, 50);
        BaseStationDevice bs3 = new BaseStationDevice("BS3", 50, 60, 50, 50);
        CloudDevice cloud = new CloudDevice("Cloud", 400, 500, 400, 400, 100);

        List<BaseStationDevice> bases = Arrays.asList(bs1, bs2, bs3, cloud);

        // ========================
        // 2. Define network topology
        // ========================
        NetworkTopology topo = new NetworkTopology();
        for (BaseStationDevice b : bases) topo.addNode(b);

        topo.addLink(new Link("L1", bs1, bs2, 100, 5));
        topo.addLink(new Link("L2", bs2, bs3, 80, 8));
        topo.addLink(new Link("L3", bs1, bs3, 60, 12));

        topo.addLink(new Link("Lcloud1", bs1, cloud, 500, 40));
        topo.addLink(new Link("Lcloud2", bs2, cloud, 500, 50));
        topo.addLink(new Link("Lcloud3", bs3, cloud, 500, 60));

        // ========================
        // 3. Define services (smaller requirements to fit on BS)
        // ========================
        ServiceModule sA = new ServiceModule("A", 10, 15, 5, 5);
        ServiceModule sB = new ServiceModule("B", 15, 20, 10, 10);
        ServiceModule sC = new ServiceModule("C", 10, 10, 5, 5);
        ServiceModule sD = new ServiceModule("D", 20, 25, 15, 15);

        List<ServiceModule> services = Arrays.asList(sA, sB, sC, sD);

        // ========================
        // 4. Define communication demands
        // ========================
        List<CommDemand> commDemands = new ArrayList<>();
        commDemands.add(new CommDemand(sA, sB, 20));
        commDemands.add(new CommDemand(sB, sC, 15));
        commDemands.add(new CommDemand(sA, sC, 10));
        commDemands.add(new CommDemand(sC, sD, 15));
        commDemands.add(new CommDemand(sB, sD, 10));

        // ========================
        // 5. Solve LP and do randomized rounding
        // ========================
        ILPFormulation ilp = new ILPFormulation();
        double[][] x = ilp.solveLP(bases, services);

        // Print LP fractional solution
        System.out.println("LP fractional solution:");
        for (int i = 0; i < services.size(); i++) {
            System.out.println(services.get(i).getName() + ": " + Arrays.toString(x[i]));
        }

        RandomizedRounding rr = new RandomizedRounding();
        PlacementResult placement = rr.roundWithRouting(x, bases, services, commDemands, topo);

        // ========================
        // 6. Print final placement
        // ========================
        System.out.println("\nFinal placement:");
        for (ServiceModule s : services) {
            BaseStationDevice b = placement.getBase(s);
            System.out.println(s.getName() + " -> " + (b != null ? b.getName() : "NOT PLACED"));
        }

        // ========================
        // 7. Print link usage
        // ========================
        System.out.println("\nLink usages:");
        for (Link l : topo.getLinks()) {
            System.out.printf("%s (%s-%s): used %.2f / cap %.2f\n",
                    l.getId(), l.getA().getName(), l.getB().getName(),
                    l.getUsedBandwidth(), l.getCapacity());
        }
    }
}
